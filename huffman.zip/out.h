#ifndef OUT_H
#define OUT_H

#include <stdio.h>
int utf8_strlen(const char* str);
void print_border(int width, int mode);
void print_line(const char* text, int width);


#endif